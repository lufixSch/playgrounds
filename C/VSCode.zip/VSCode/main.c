#include <stdio.h>

const char* str = "HALLO";
char num[] = { 1, 2, 3, 4 };

char Arr1[][4] = { "A", "B", "C", "D" };
const char* arr2[] = { "A", "B", "C", "D" };

char func(char* arr) {
  char b = arr[0];
  while (1) { }

  switch (b) {
  case 1 /* constant-expression */:
    /* code */
    break;

  default:
    break;
  }

  return b;
}
